import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lifecapsule8_app/provider/future/future_letter_provider.dart';

class FutureLetterWritePage extends ConsumerStatefulWidget {
  const FutureLetterWritePage({super.key});

  @override
  ConsumerState<FutureLetterWritePage> createState() =>
      _FutureLetterWritePageState();
}

class _FutureLetterWritePageState extends ConsumerState<FutureLetterWritePage> {
  final _textCtrl = TextEditingController();
  bool _inited = false;
  bool _persisted = false;
  @override
  void dispose() {
    _textCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    if (_inited) return;
    _inited = true;

    final cur = ref.read(futureLetterProvider).currentFutureLetter;

    if (cur == null) {
      if (mounted) Navigator.pop(context);
      return;
    }

    _textCtrl.text = cur.content;

    if (mounted) setState(() {});
  }

  Future<void> _ensurePersisted() async {
    if (_persisted) return;
    _persisted = true;
    await ref.read(futureLetterProvider.notifier).persistCurrent();
  }

  @override
  Widget build(BuildContext context) {
    // 用 microtask 避免 build 里 await
    Future.microtask(_init);

    final cur = ref.watch(futureLetterProvider).currentFutureLetter;
    final canNext = _textCtrl.text.trim().isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Write Letter To Future',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            // 可选：离开时不清 current，方便返回继续编辑
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            tooltip: 'All letters',
            icon: const Icon(Icons.list),
            onPressed: () {
              Navigator.pushNamed(context, '/FutureLetterListPage');
            },
          ),
        ],
      ),
      body: cur == null
          ? const Center(child: Text('No letter selected'))
          : Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _textCtrl,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      decoration: const InputDecoration(
                        hintText: 'Write your letter…',
                        // border: OutlineInputBorder(),
                        alignLabelWithHint: true,
                        contentPadding: EdgeInsets.all(8),
                      ),
                      onChanged: (v) async {
                        setState(() {});
                        ref
                            .read(futureLetterProvider.notifier)
                            .saveContentOnCurrent(v);

                        if (v.trim().isNotEmpty) {
                          await _ensurePersisted(); // ✅ 有内容才落盘
                        }
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: canNext
                            ? () async {
                                await _ensurePersisted();
                                if (!mounted) return;
                                if (!context.mounted) return;
                                // ✅ 下一步：Schedule（When）
                                Navigator.pushNamed(
                                  context,
                                  '/FutureLetterSchedulePage',
                                );
                              }
                            : null,
                        child: const Text(
                          'Next',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
    );
  }
}
