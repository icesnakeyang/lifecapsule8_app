import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lifecapsule8_app/provider/note/note_provider.dart';

class LoveLetter extends ConsumerStatefulWidget {
  const LoveLetter({super.key});

  @override
  ConsumerState<LoveLetter> createState() => _LoveLetterState();
}

class _LoveLetterState extends ConsumerState<LoveLetter>
    with WidgetsBindingObserver {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  bool _inited = false;
  String? _noteId;

  late final VoidCallback _onTextChanged;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _onTextChanged = () {
      final id = _noteId;
      if (id == null) return;
      ref.read(noteProvider.notifier).updateNoteById(id, _controller.text);
    };
    _controller.addListener(_onTextChanged);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_inited) return;
    _inited = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _initLoveLetter();
    });
  }

  Future<void> _initLoveLetter() async {
    final notifier = ref.read(noteProvider.notifier);
    final existing = ref.read(noteProvider).currentNote;

    if (existing != null && existing.type != 'LOVE_LETTER') {
      notifier.clearCurrentNote();
    }
    var currentNote = ref.read(noteProvider).currentNote;
    if (currentNote == null) {
      final newNote = await notifier.createEmptyCurrentNote(
        type: 'LOVE_LETTER',
      );
      currentNote = newNote;
    }

    if (!mounted) return;

    _noteId = currentNote.id;
    _controller.text = currentNote.content;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (_focusNode.canRequestFocus) _focusNode.requestFocus();
    });

    setState(() {});
  }

  /// 切后台自动保存（与 PrivateNote 一致）
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      final id = _noteId;
      if (id != null) {
        ref
            .read(noteProvider.notifier)
            .autoSaveOnBackground(id, _controller.text);
      }
    }
  }

  Future<void> _saveOrDeleteBeforeExit() async {
    final id = _noteId;
    if (id == null) return;
    await ref
        .read(noteProvider.notifier)
        .saveOrDeleteNoteById(id, _controller.text);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentnote = ref.watch(noteProvider).currentNote;
    final text = _controller.text;
    final canNext = currentnote != null && text.trim().isNotEmpty;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final navigator = Navigator.of(context);
        await _saveOrDeleteBeforeExit();
        if (!navigator.mounted) return;
        navigator.pop(result);
      },
      child: Scaffold(
        extendBodyBehindAppBar: true, // 让渐变背景延伸到AppBar下方
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text(
            'Love Letter',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.white,
              shadows: [Shadow(color: Colors.black26, blurRadius: 4)],
            ),
          ),
          centerTitle: false,
          iconTheme: const IconThemeData(color: Colors.white),
          actions: [
            // IconButton(
            //   onPressed: () async {
            //     final navigator = Navigator.of(context);
            //     final notifier = ref.read(noteProvider.notifier);
            //     notifier.clearCurrentNote();
            //     navigator.pushNamed('/LoveLetter'); // 你的 LoveLetter 编辑页路由
            //   },
            //   icon: const Icon(Icons.add),
            // ),
            IconButton(
              icon: const Icon(Icons.list),
              onPressed: () async {
                await _saveOrDeleteBeforeExit();
                if (!mounted) return;
                Navigator.pushNamed(context, '/LoveLetterList');
              },
            ),
            TextButton(
              onPressed: canNext
                  ? () {
                      Navigator.pushNamed(context, '/LoveLetterNext2');
                    }
                  : null,
              child: Text(
                'Next',
                style: TextStyle(
                  color: canNext ? Colors.white : Colors.white54,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  shadows: const [Shadow(color: Colors.black26, blurRadius: 4)],
                ),
              ),
            ),
          ],
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(158, 135, 2, 111), // 柔和粉红
                Color.fromARGB(255, 41, 1, 23),
              ],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      maxLines: null, // 无限制行数
                      expands: true, // 填充容器高度
                      textAlignVertical: TextAlignVertical.top,
                      scrollPadding: EdgeInsets.zero,
                      decoration: const InputDecoration(
                        isCollapsed: true,
                        contentPadding: EdgeInsets.zero,
                        border: InputBorder.none,
                        hintText:
                            'Dear...\n\n'
                            "I keep thinking about you.\n"
                            "The way you look at me stirs something deep indide, "
                            "and I can't seem to focus on anything else.\n\n"
                            "I don't know how to say this out loud.\n"
                            "I want to see you.\n"
                            "No matter what happens, I want to be with you.",
                        hintStyle: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          height: 1.8,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
