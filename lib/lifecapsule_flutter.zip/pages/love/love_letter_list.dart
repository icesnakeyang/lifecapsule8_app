import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lifecapsule8_app/provider/note/local_note.dart';
import 'package:lifecapsule8_app/provider/note/note_provider.dart';

class LoveLetterList extends ConsumerStatefulWidget {
  const LoveLetterList({super.key});

  @override
  ConsumerState<LoveLetterList> createState() => _LoveLetterListState();
}

class _LoveLetterListState extends ConsumerState<LoveLetterList> {
  static const String loveType = 'LOVE_LETTER';

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(noteProvider.notifier).removeEmptyNotes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(noteProvider);

    // 只显示 LOVE_LETTER
    final List<LocalNote> letters = state.notes
        .where((n) => n.type == loveType)
        .toList();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        final navigator = Navigator.of(context);
        navigator.popUntil((route) => route.isFirst);
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text(
            "Love Letters",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.white,
              shadows: [Shadow(color: Colors.black26, blurRadius: 4)],
            ),
          ),
          iconTheme: const IconThemeData(color: Colors.white),
          actions: [
            IconButton(
              onPressed: () async {
                final navigator = Navigator.of(context);
                final notifier = ref.read(noteProvider.notifier);
                notifier.clearCurrentNote();
                navigator.pushNamed('/LoveLetter'); // 你的 LoveLetter 编辑页路由
              },
              icon: const Icon(Icons.add),
            ),
          ],
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(158, 135, 2, 111),
                Color.fromARGB(255, 41, 1, 23),
              ],
            ),
          ),
          child: SafeArea(
            child: letters.isEmpty
                ? const Center(
                    child: Text(
                      "No love letters yet",
                      style: TextStyle(color: Colors.white70),
                    ),
                  )
                : ListView.builder(
                    itemCount: letters.length,
                    itemBuilder: (context, index) {
                      final item = letters[index];
                      final content = item.content;
                      final updatedAt = item.updatedAt;
                      final title = content.trim().split("\n").first;

                      return ListTile(
                        title: Text(
                          title.isEmpty ? "(Empty letter)" : title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white),
                        ),
                        subtitle: Text(
                          DateFormat.yMd().add_Hm().format(updatedAt),
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.white70,
                          ),
                        ),
                        onTap: () {
                          ref
                              .read(noteProvider.notifier)
                              .setCurrentNoteById(item.id);
                          Navigator.pushNamed(
                            context,
                            '/LoveLetter',
                            arguments: {'id': item.id, 'content': item.content},
                          );
                        },
                      );
                    },
                  ),
          ),
        ),
      ),
    );
  }
}
