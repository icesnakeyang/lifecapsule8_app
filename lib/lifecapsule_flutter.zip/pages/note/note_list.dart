import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:lifecapsule8_app/crypto/crypto_provider.dart';
import 'package:lifecapsule8_app/provider/note/local_note.dart';
import 'package:lifecapsule8_app/provider/note/note_provider.dart';
import 'package:lifecapsule8_app/theme/theme_provider.dart';

class NoteList extends ConsumerStatefulWidget {
  const NoteList({super.key});

  @override
  ConsumerState<NoteList> createState() => _NoteListState();
}

class _NoteListState extends ConsumerState<NoteList> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(noteProvider.notifier).removeEmptyNotes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(noteProvider);
    final List<LocalNote> notes = state.notes
        .where((n) => n.type == 'PRIVATE_NOTE')
        .toList();
    final theme = ref.watch(themeProvider);
    final crypto = ref.watch(cryptoProvider);
    final isEncrypted = crypto.hasMnemonic && crypto.hasMasterKey;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        final navigator = Navigator.of(context);
        navigator.popUntil((route) => route.isFirst);
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "My Notes",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          actions: [
            IconButton(
              onPressed: () async {
                final navigator = Navigator.of(context);
                final notifier = ref.read(noteProvider.notifier);
                notifier.clearCurrentNote();
                navigator.pushNamed('/noteedit');
              },
              icon: const Icon(Icons.add),
            ),
            IconButton(
              onPressed: () {
                Navigator.pushNamed(context, '/cryptosetting');
              },
              icon: Icon(
                isEncrypted ? Icons.lock : Icons.lock_open,
                color: isEncrypted ? theme.success : theme.error,
              ),
            ),
          ],
        ),
        body: notes.isEmpty
            ? const Center(child: Text("No notes yet"))
            : ListView.builder(
                itemCount: notes.length,
                itemBuilder: (context, index) {
                  final item = notes[index];
                  final content = item.content;
                  final updatedAt = item.updatedAt;
                  final title = content.trim().split("\n").first;

                  return ListTile(
                    title: Text(
                      title.isEmpty ? "(Empty note)" : title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      DateFormat.yMd().add_Hm().format(updatedAt),
                      style: const TextStyle(fontSize: 12),
                    ),
                    onTap: () {
                      ref
                          .read(noteProvider.notifier)
                          .setCurrentNoteById(item.id);
                      Navigator.pushNamed(
                        context,
                        '/noteedit',
                        arguments: {'id': item.id, 'content': item.content},
                      );
                    },
                  );
                },
              ),
      ),
    );
  }
}
