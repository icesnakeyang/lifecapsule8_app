// lib/provider/future/future_letter_provider.dart
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

import 'package:lifecapsule8_app/hive/hive_boxes.dart';
import 'package:lifecapsule8_app/provider/future/future_letter_draft.dart';
import 'package:lifecapsule8_app/provider/future/future_letter_state.dart';
import 'package:lifecapsule8_app/provider/send_task/send_task_model.dart';
import 'package:lifecapsule8_app/provider/send_task/send_task_notifier.dart';
import 'package:lifecapsule8_app/utils/dt_localized.dart';

final futureLetterProvider =
    NotifierProvider<FutureLetterNotifier, FutureLetterState>(
      FutureLetterNotifier.new,
    );

class FutureLetterNotifier extends Notifier<FutureLetterState> {
  late final Box<String> _box = Hive.box<String>(HiveBoxes.futureBox);

  @override
  FutureLetterState build() {
    final list = _loadAllFromHive();
    return FutureLetterState(
      currentFutureLetter: null,
      futureLetterList: list,
      loading: false,
      errMsg: null,
    );
  }

  // ---------- hive helpers ----------

  List<FutureLetterDraft> _loadAllFromHive() {
    final list = <FutureLetterDraft>[];
    for (final k in _box.keys) {
      final noteId = k.toString();
      final raw = _box.get(noteId);
      if (raw == null || raw.isEmpty) continue;
      try {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        final d = FutureLetterDraft.fromJson(map);
        if (d.noteId.isNotEmpty) list.add(d);
      } catch (_) {}
    }
    // 最新在前（你可按 updatedAt 排）
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  Future<void> _upsertToHive(FutureLetterDraft d) async {
    await _box.put(d.noteId, jsonEncode(d.toJson()));
  }

  Future<void> _deleteFromHive(String noteId) async {
    await _box.delete(noteId);
  }

  void _reloadListKeepCurrent() {
    final list = _loadAllFromHive();
    FutureLetterDraft? cur = state.currentFutureLetter;

    if (cur != null) {
      // 用最新的 list 里的版本覆盖 current（保持一致）
      final latest = list.where((e) => e.noteId == cur!.noteId).toList();
      cur = latest.isEmpty ? null : latest.first;
    }

    state = state.copyWith(futureLetterList: list, currentFutureLetter: cur);
  }

  // ---------- public API ----------

  String _genNoteId() => 'future_${DateTime.now().microsecondsSinceEpoch}';
  Future<FutureLetterDraft> createAndSelectDraft() async {
    final noteId = _genNoteId();

    final d = FutureLetterDraft(
      noteId: noteId,
      updatedAt: DateTime.now(),
      content: '',
    );

    await _upsertToHive(d);

    // ✅ 直接把 current 指到新 draft（不用依赖 list reload 再 set）
    state = state.copyWith(currentFutureLetter: d);

    // ✅ 刷新列表 & 用 hive 最新版本覆盖 current
    _reloadListKeepCurrent();

    return d;
  }

  // ✅ 只创建一个 current draft（不写 Hive）
  FutureLetterDraft createDraftInMemory() {
    final noteId = 'future_${DateTime.now().microsecondsSinceEpoch}';
    final d = FutureLetterDraft(
      noteId: noteId,
      updatedAt: DateTime.now(),
      content: '',
    );

    state = state.copyWith(currentFutureLetter: d);
    return d;
  }

  Future<void> persistCurrent() async {
    final cur = state.currentFutureLetter;
    if (cur == null) return;

    await _upsertToHive(cur);
    _reloadListKeepCurrent();
  }

  /// 列表页点击某一封时调用：设置 currentFutureLetter
  void setCurrentByNoteId(String noteId) {
    final found = state.futureLetterList
        .where((e) => e.noteId == noteId)
        .toList();
    state = state.copyWith(
      currentFutureLetter: found.isEmpty ? null : found[0],
    );
  }

  void clearCurrent() {
    state = state.copyWith(clearCurrentFutureLetter: true);
  }

  /// 新建一封 future letter（返回 noteId 给列表页用；之后 setCurrentByNoteId 再进入流程）
  Future<FutureLetterDraft> createNew({required String noteId}) async {
    final d = FutureLetterDraft(
      noteId: noteId,
      updatedAt: DateTime.now(),
      content: '',
    );
    await _upsertToHive(d);
    _reloadListKeepCurrent();
    return d;
  }

  /// 保存收件人字段（只改 current，不需要 noteId 传来传去）
  Future<void> saveRecipientOnCurrent({
    String? userCode,
    String? userId,
    String? nickname,
    String? email,
    String? toName,
    String? fromName,
    bool clearEmail = false,
    bool clearToName = false,
    bool clearFromName = false,
    bool clearRecipient = false,
  }) async {
    final cur = state.currentFutureLetter;
    if (cur == null) throw Exception('No current future letter');

    final next = cur.copyWith(
      updatedAt: DateTime.now(),
      userCode: userCode,
      userId: userId,
      nickname: nickname,
      email: email,
      toName: toName,
      fromName: fromName,
      clearRecipient: clearRecipient,
      clearEmail: clearEmail,
      clearToName: clearToName,
      clearFromName: clearFromName,
    );

    await _upsertToHive(next);
    _reloadListKeepCurrent();
  }

  Future<void> saveSendAtOnCurrent({required DateTime sendAtLocal}) async {
    final cur = state.currentFutureLetter;
    if (cur == null) throw Exception('No current future letter');

    final next = cur.copyWith(
      updatedAt: DateTime.now(),
      sendAtIso: toIso8601WithOffset(sendAtLocal),
      clearSendAt: false,
    );

    await _upsertToHive(next);
    _reloadListKeepCurrent();
  }

  Future<void> clearSendAtOnCurrent() async {
    final cur = state.currentFutureLetter;
    if (cur == null) return;

    final next = cur.copyWith(updatedAt: DateTime.now(), clearSendAt: true);
    await _upsertToHive(next);
    _reloadListKeepCurrent();
  }

  Future<void> deleteCurrent() async {
    final cur = state.currentFutureLetter;
    if (cur == null) return;

    await _deleteFromHive(cur.noteId);
    state = state.copyWith(clearCurrentFutureLetter: true);
    _reloadListKeepCurrent();
  }

  /// confirmSend：完全不需要 noteId 参数（从 current 拿）
  Future<void> confirmSendCurrent() async {
    try {
      state = state.copyWith(clearErrMsg: true);
      final d = state.currentFutureLetter;
      if (d == null) throw Exception('No current future letter');

      if (d.content.trim().isEmpty) throw Exception('Content is empty');

      final userCode = (d.userCode ?? '').trim();
      final email = (d.email ?? '').trim();
      if (userCode.isEmpty && email.isEmpty) {
        throw Exception('Recipient not set');
      }

      final scheduleAtIso = (d.sendAtIso ?? '').trim();
      if (scheduleAtIso.isEmpty) throw Exception('Send time not set');

      final recipient = RecipientPayload(
        userCode: userCode.isEmpty ? null : userCode,
        email: email.isEmpty ? null : email,
        self: false,
      );

      final idemKey = [
        SendTaskType.future.name,
        d.noteId,
        SendScheduleType.atTime.name,
        recipient.userCode ?? '',
        recipient.email ?? '',
        scheduleAtIso,
      ].join('|');

      await ref
          .read(sendTaskProvider.notifier)
          .enqueue(
            idemKey: idemKey,
            type: SendTaskType.future,
            scheduleType: SendScheduleType.atTime,
            scheduleAtIso: scheduleAtIso,
            triggerRef: null,
            recipient: recipient,
            payloadRef: d.noteId,
            cryptoMode: CryptoMode.none,
            cryptoHint: null,
          );

      await ref.read(sendTaskProvider.notifier).syncToCloud();

      // ✅ Confirm 成功后的收尾：清 current / 清错误 / 刷新列表
      state = state.copyWith(clearCurrentFutureLetter: true, clearErrMsg: true);
      _reloadListKeepCurrent();
    } catch (e) {
      _setErrFrom(e.toString());
      rethrow;
    }
  }

  void _setErrFrom(Object e) {
    final msg = (e is Exception)
        ? e.toString().replaceFirst('Exception: ', '')
        : e.toString();
    state = state.copyWith(errMsg: msg);
  }

  void clearErr() {
    state = state.copyWith(clearErrMsg: true);
  }

  Future<void> saveContentOnCurrent(String content) async {
    final cur = state.currentFutureLetter;
    if (cur == null) throw Exception('No current future letter');

    final next = cur.copyWith(updatedAt: DateTime.now(), content: content);

    await _upsertToHive(next);
    _reloadListKeepCurrent();
  }
}
