import 'dart:convert';

enum SendTaskType { love, future, lastWishes }

enum SendTaskStatus { pending, scheduled, sending, sent, failed, canceled }

enum SendScheduleType { instantly, atTime }

enum CryptoMode { none, passcode, qa }

class RecipientPayload {
  final String? email; // 用户填写
  final String? userCode; // 用户选择/填写（给后端解析）
  final bool self; // UI 快捷方式：发给自己（不是分类）

  const RecipientPayload({this.email, this.userCode, this.self = false});

  RecipientPayload copyWith({String? email, String? userCode, bool? self}) {
    return RecipientPayload(
      email: email ?? this.email,
      userCode: userCode ?? this.userCode,
      self: self ?? this.self,
    );
  }

  Map<String, dynamic> toJson() => {
    'email': email,
    'userCode': userCode,
    'self': self,
  };

  static RecipientPayload fromJson(Map<String, dynamic> m) {
    return RecipientPayload(
      email: m['email'] as String?,
      userCode: m['userCode'] as String?,
      self: (m['self'] as bool?) ?? false,
    );
  }
}

class SendTask {
  final String taskId;

  final SendTaskType type;
  final SendTaskStatus status;

  final SendScheduleType scheduleType;
  final String? scheduleAtIso; // for atTime
  final String? triggerRef; // countdownId / conditionId

  final RecipientPayload recipient;

  final String payloadRef; // noteId / futureId / wishId

  final CryptoMode cryptoMode;
  final String? cryptoHint; // e.g. QA question (safe to show), optional

  final int retryCount;
  final String? lastError;

  final String createdAtIso;
  final String updatedAtIso;

  // 幂等键规则（必须在 Notifier 层保证）：
  // - lastWishes: 固定为 'last_wishes:$payloadRef'
  // - love / future: 可以包含 scheduleType / recipientRef
  final String idemKey;

  const SendTask({
    required this.taskId,
    required this.idemKey,
    required this.type,
    required this.status,
    required this.scheduleType,
    required this.recipient,
    required this.payloadRef,
    required this.cryptoMode,
    required this.createdAtIso,
    required this.updatedAtIso,
    this.scheduleAtIso,
    this.triggerRef,
    this.cryptoHint,
    this.retryCount = 0,
    this.lastError,
  });

  SendTask copyWith({
    SendTaskStatus? status,
    String? scheduleAtIso,
    String? triggerRef,
    RecipientPayload? recipient,
    CryptoMode? cryptoMode,
    String? cryptoHint,
    int? retryCount,
    String? lastError,
    String? updatedAtIso,
  }) {
    return SendTask(
      taskId: taskId,
      idemKey: idemKey,
      type: type,
      status: status ?? this.status,
      scheduleType: scheduleType,
      scheduleAtIso: scheduleAtIso ?? this.scheduleAtIso,
      triggerRef: triggerRef ?? this.triggerRef,
      recipient: recipient ?? this.recipient,
      payloadRef: payloadRef,
      cryptoMode: cryptoMode ?? this.cryptoMode,
      cryptoHint: cryptoHint ?? this.cryptoHint,
      retryCount: retryCount ?? this.retryCount,
      lastError: lastError ?? this.lastError,
      createdAtIso: createdAtIso,
      updatedAtIso: updatedAtIso ?? this.updatedAtIso,
    );
  }

  static SendTask fromJson(Map<String, dynamic> m) {
    final t = SendTask(
      taskId: m['taskId'] as String,
      idemKey: (m['idemKey'] as String?) ?? '',
      type: SendTaskType.values.byName(m['type'] as String),
      status: SendTaskStatus.values.byName(m['status'] as String),
      scheduleType: SendScheduleType.values.byName(m['scheduleType'] as String),
      scheduleAtIso: m['scheduleAtIso'] as String?,
      triggerRef: m['triggerRef'] as String?,
      recipient: RecipientPayload.fromJson(
        (m['recipient'] as Map).cast<String, dynamic>(),
      ),
      payloadRef: m['payloadRef'] as String,
      cryptoMode: CryptoMode.values.byName(m['cryptoMode'] as String),
      cryptoHint: m['cryptoHint'] as String?,
      retryCount: (m['retryCount'] as num?)?.toInt() ?? 0,
      lastError: m['lastError'] as String?,
      createdAtIso: m['createdAtIso'] as String,
      updatedAtIso: m['updatedAtIso'] as String,
    );
    // 可选：反序列化后做校验（避免历史脏数据导致后续崩）
    // t.validate();
    return t;
  }

  /// ✅ 建议：做一个轻量校验，防止 atTime 没填 scheduleAtIso
  void validate() {
    if (scheduleType == SendScheduleType.atTime) {
      final s = scheduleAtIso?.trim() ?? '';
      if (s.isEmpty) {
        throw StateError(
          'SendTask(scheduleType=atTime) requires scheduleAtIso',
        );
      }
    }
    if (type == SendTaskType.lastWishes) {
      assert(
        scheduleType == SendScheduleType.atTime,
        'lastWishes must use atTime schedule',
      );
    }
  }

  Map<String, dynamic> toJson() => {
    'taskId': taskId,
    'type': type.name,
    'status': status.name,
    'scheduleType': scheduleType.name,
    'scheduleAtIso': scheduleAtIso,
    'triggerRef': triggerRef,
    'recipient': recipient.toJson(),
    'payloadRef': payloadRef,
    'cryptoMode': cryptoMode.name,
    'cryptoHint': cryptoHint,
    'retryCount': retryCount,
    'lastError': lastError,
    'createdAtIso': createdAtIso,
    'updatedAtIso': updatedAtIso,
    'idemKey': idemKey,
  };

  String encode() => jsonEncode(toJson());

  static SendTask decode(String raw) => fromJson(jsonDecode(raw));
}
