// lib/provider/love_letter/love_letter_provider.dart
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:lifecapsule8_app/hive/hive_boxes.dart';
import 'package:lifecapsule8_app/provider/love_letter/love_letter_draft.dart';
import 'package:lifecapsule8_app/provider/love_letter/love_letter_state.dart';
import 'package:lifecapsule8_app/provider/send_task/builders/love_send_task_builder.dart';
import 'package:lifecapsule8_app/provider/send_task/send_task_notifier.dart';
import 'package:lifecapsule8_app/utils/dt_localized.dart';

final loveLetterProvider =
    NotifierProvider<LoveLetterNotifier, LoveLetterState>(() {
      return LoveLetterNotifier();
    });

class LoveLetterNotifier extends Notifier<LoveLetterState> {
  // 你需要在 HiveBoxes 里新增一个 key，比如：
  // static const loveLetterDrafts = 'love_letter_drafts';
  late final Box _draftBox = Hive.box(HiveBoxes.loveLetterDrafts);

  @override
  LoveLetterState build() {
    final drafts = <String, LoveLetterDraft>{};
    for (final k in _draftBox.keys) {
      final key = k.toString();
      final raw = _draftBox.get(key);
      if (raw == null) continue;
      try {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        final d = LoveLetterDraft.fromJson(map);
        if (d.noteId.isNotEmpty) drafts[d.noteId] = d;
      } catch (_) {}
    }
    return LoveLetterState(draftsByNoteId: drafts);
  }

  LoveLetterDraft? getDraft(String noteId) {
    return state.draftsByNoteId[noteId];
  }

  void setCurrentDraft(String noteId) {
    state = state.copyWith(currentDraft: state.draftsByNoteId[noteId]);
  }

  void clearCurrentDraft() {
    state = state.copyWith(clearCurrentDraft: true);
  }

  Future<LoveLetterDraft> ensureDraft(String noteId) async {
    final existing = state.draftsByNoteId[noteId];
    if (existing != null) {
      return existing;
    }

    final created = LoveLetterDraft(noteId: noteId, updatedAt: DateTime.now());
    await _draftBox.put(noteId, jsonEncode(created.toJson()));

    final newMap = {...state.draftsByNoteId, noteId: created};
    state = state.copyWith(draftsByNoteId: newMap);
    return created;
  }

  Future<void> saveRecipient({
    required String noteId,
    required String toType, // 'USER' | 'EMAIL'
    String? userCode,
    String? userId,
    String? nickname,
    String? email,
    String? toName,
    String? fromName,
    bool clearEmail = false,
    bool clearToName = false,
    bool clearFromName = false,
  }) async {
    final base =
        state.draftsByNoteId[noteId] ??
        LoveLetterDraft(noteId: noteId, updatedAt: DateTime.now());

    final next = base.copyWith(
      updatedAt: DateTime.now(),
      toType: toType,
      userCode: userCode,
      userId: userId,
      nickname: nickname,
      email: email,
      toName: toName,
      fromName: fromName,
      clearRecipient: false,
      clearEmail: clearEmail,
      clearToName: clearToName,
      clearFromName: clearFromName,
    );

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    final newMap = {...state.draftsByNoteId, noteId: next};
    state = state.copyWith(draftsByNoteId: newMap, currentDraft: next);
  }

  Future<void> clearRecipient(String noteId) async {
    final base = state.draftsByNoteId[noteId];
    if (base == null) return;

    final next = base.copyWith(updatedAt: DateTime.now(), clearRecipient: true);

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    final newMap = {...state.draftsByNoteId, noteId: next};
    state = state.copyWith(draftsByNoteId: newMap, currentDraft: next);
  }

  Future<void> saveSendAt({
    required String noteId,
    required DateTime sendAtLocal,
  }) async {
    final base =
        state.draftsByNoteId[noteId] ??
        LoveLetterDraft(noteId: noteId, updatedAt: DateTime.now());

    final next = base.copyWith(
      updatedAt: DateTime.now(),
      sendAtIso: toIso8601WithOffset(sendAtLocal),
      clearSendAt: false,
    );

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    final newMap = {...state.draftsByNoteId, noteId: next};
    state = state.copyWith(draftsByNoteId: newMap, currentDraft: next);
  }

  Future<void> clearSendAt(String noteId) async {
    final base = state.draftsByNoteId[noteId];
    if (base == null) return;

    final next = base.copyWith(updatedAt: DateTime.now(), clearSendAt: true);

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    final newMap = {...state.draftsByNoteId, noteId: next};
    state = state.copyWith(draftsByNoteId: newMap, currentDraft: next);
  }

  Future<void> deleteDraft(String noteId) async {
    await _draftBox.delete(noteId);

    final newMap = {...state.draftsByNoteId}..remove(noteId);

    state = state.copyWith(draftsByNoteId: newMap);
  }

  Future<void> saveSendMode({
    required String noteId,
    required String mode,
  }) async {
    final base =
        state.draftsByNoteId[noteId] ??
        LoveLetterDraft(noteId: noteId, updatedAt: DateTime.now());

    final next = base.copyWith(
      updatedAt: DateTime.now(),
      sendMode: mode,
      clearSendMode: false,
    );

    await _draftBox.put(noteId, jsonEncode(next.toJson()));
    state = state.copyWith(
      draftsByNoteId: {...state.draftsByNoteId, noteId: next},
      currentDraft: next,
    );
  }

  Future<void> clearSendMode(String noteId) async {
    final base = state.draftsByNoteId[noteId];
    if (base == null) return;

    final next = base.copyWith(updatedAt: DateTime.now(), clearSendMode: true);

    await _draftBox.put(noteId, jsonEncode(next.toJson()));
    state = state.copyWith(
      draftsByNoteId: {...state.draftsByNoteId, noteId: next},
      currentDraft: next,
    );
  }

  Future<void> savePasscode({
    required String noteId,
    required String mode, // 'NONE' | 'PASSCODE' | 'QA'
    String? passcode, // PASSCODE: raw ; QA: json string
    bool clearPasscode = false,
  }) async {
    final base =
        state.draftsByNoteId[noteId] ??
        LoveLetterDraft(noteId: noteId, updatedAt: DateTime.now());

    final next = base.copyWith(
      updatedAt: DateTime.now(),
      passcodeMode: mode,
      passcode: passcode,
      clearPasscode: clearPasscode,
    );

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    state = state.copyWith(
      draftsByNoteId: {...state.draftsByNoteId, noteId: next},
      currentDraft: next,
    );
  }

  Future<void> clearPasscode(String noteId) async {
    final base = state.draftsByNoteId[noteId];
    if (base == null) return;

    final next = base.copyWith(updatedAt: DateTime.now(), clearPasscode: true);

    await _draftBox.put(noteId, jsonEncode(next.toJson()));

    state = state.copyWith(
      draftsByNoteId: {...state.draftsByNoteId, noteId: next},
      currentDraft: next,
    );
  }

  Future<void> confirmSend(String noteId) async {
    await ensureDraft(noteId);
    final d = getDraft(noteId);
    if (d == null) throw Exception('Draft not found');

    // 1) recipient 校验
    final toType = (d.toType ?? 'EMAIL').toUpperCase();
    if (toType == 'USER') {
      final uid = (d.userId ?? '').trim();
      if (uid.isEmpty) throw Exception('Recipient user not set');
    } else if (toType == 'EMAIL') {
      final email = (d.email ?? '').trim();
      if (email.isEmpty) throw Exception('Recipient email not set');
    } else {
      throw Exception('Invalid recipient type: $toType');
    }

    // 2) sendMode 校验（不考虑 LATER）
    final sendMode = (d.sendMode ?? 'SPECIFIC_TIME').toUpperCase();
    if (sendMode != 'SPECIFIC_TIME' &&
        sendMode != 'INSTANTLY' &&
        sendMode != 'PRIMARY_COUNTDOWN') {
      throw Exception('Invalid send mode: $sendMode');
    }

    if (sendMode == 'SPECIFIC_TIME') {
      final iso = (d.sendAtIso ?? '').trim();
      if (iso.isEmpty) throw Exception('Send time not set');
    }

    // 3) passcode 校验
    final passMode = (d.passcodeMode ?? 'NONE').toUpperCase();
    if (passMode != 'NONE' && passMode != 'PASSCODE' && passMode != 'QA') {
      throw Exception('Invalid passcode mode: $passMode');
    }

    if (passMode == 'PASSCODE') {
      final p = (d.passcode ?? '').trim();
      if (p.isEmpty) throw Exception('Passcode not set');
    } else if (passMode == 'QA') {
      final raw = (d.passcode ?? '').trim();
      if (raw.isEmpty) throw Exception('Q&A not set');
      try {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        final q = (map['q'] as String?)?.trim() ?? '';
        final a = (map['a'] as String?)?.trim() ?? '';
        if (q.isEmpty || a.isEmpty) throw Exception('Q&A not set');
      } catch (_) {
        throw Exception('Invalid Q&A payload');
      }
    }

    // 4) build -> enqueue unified SendTask（带幂等键，避免重复创建）
    final builder = LoveSendTaskBuilder();
    final r = builder.build(d);

    // PRIMARY_COUNTDOWN：当前 draft 没 countdownId，所以 builder triggerRef 为 null
    // 这里直接禁止，避免创建“无法触发的任务”
    if (r.scheduleType.name == 'primaryCountdown' &&
        (r.triggerRef?.isNotEmpty != true)) {
      throw Exception('Primary countdown not configured');
    }

    await ref
        .read(sendTaskProvider.notifier)
        .enqueue(
          idemKey: r.idemKey, // ✅
          type: r.type,
          scheduleType: r.scheduleType,
          scheduleAtIso: r.scheduleAtIso,
          triggerRef: r.triggerRef,
          recipient: r.recipient,
          payloadRef: r.payloadRef,
          cryptoMode: r.cryptoMode,
          cryptoHint: r.cryptoHint,
        );
  }
}
