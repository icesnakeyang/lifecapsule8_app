import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:lifecapsule8_app/api/api.dart';
import 'package:lifecapsule8_app/crypto/crypto_provider.dart';
import 'package:lifecapsule8_app/crypto/note_cipher.dart';
import 'package:lifecapsule8_app/hive/hive_boxes.dart';
import 'package:lifecapsule8_app/provider/note/local_note.dart';
import 'package:lifecapsule8_app/provider/note/note_state.dart';
import 'package:lifecapsule8_app/provider/send_task/send_task_notifier.dart';
import 'package:lifecapsule8_app/utils/dt_localized.dart';
import 'package:uuid/uuid.dart';

final noteProvider = NotifierProvider<NoteNotifier, NoteState>(() {
  return NoteNotifier();
});

class NoteNotifier extends Notifier<NoteState> {
  late final Box<String> _notesBox = Hive.box<String>(HiveBoxes.notes);

  Timer? _syncTimer;

  Uint8List? get _masterKey => ref.read(cryptoProvider.notifier).masterKey;

  Iterable<Map<String, dynamic>> _iterPendingRecords() sync* {
    for (final raw in _notesBox.values) {
      try {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        final isSynced = map['isSynced'] as bool? ?? false;
        if (!isSynced) yield map;
      } catch (_) {}
    }
  }

  Future<void> _uploadRecordToServer(Map<String, dynamic> m) async {
    final clientNoteId = m['id'] as String?;
    if (clientNoteId == null || clientNoteId.isEmpty) return;

    final encRaw = m['enc'] as String?;
    final isDeleted = m['isDeleted'] as bool? ?? false;

    // 如果你坚持“必须加密才能上云”，这里直接 return
    if (encRaw == null || encRaw.isEmpty) return;

    late final NoteCipherParts parts;
    try {
      parts = NoteCipher.unpackCompactString(encRaw);
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('unpackCompactString failed for note=$clientNoteId: $e');
        debugPrint('$st');
      }
      return;
    }
    final ivB64 = parts.iv;
    final cipherTextB64 = parts.ciphertext;
    final tagB64 = parts.authTag;

    String normalizeIso(dynamic v) {
      if (v == null) return toIso8601WithOffset(DateTime.now());
      if (v is DateTime) return toIso8601WithOffset(v);
      final s = v.toString();
      // 已经带 Z 或 +hh:mm 就不动
      final hasOffset =
          s.endsWith('Z') || RegExp(r'.*[+-]\d\d:\d\d$').hasMatch(s);
      return hasOffset ? s : '$s+00:00'; // 极端兜底（建议不要走到这里）
    }

    final metaObj = m['meta'];
    String? metaJson;
    if (metaObj is Map) {
      metaJson = jsonEncode(metaObj);
    } else if (metaObj is String && metaObj.trim().isNotEmpty) {
      // 兼容：如果你未来把 meta 存成 string
      metaJson = metaObj;
    }

    final params = <String, dynamic>{
      "noteId": m['serverNoteId'],
      "clientNoteId": clientNoteId,
      "entityType": m['type'] ?? 'PRIVATE_NOTE',

      // ✅ 推荐：后端字段也统一叫 cipherText（或 encText，但只放 ciphertext）
      "cipherText": cipherTextB64,
      "encAlg": "AES_GCM",
      "ivB64": ivB64,
      "tagB64": tagB64,
      // ✅ 新增：业务元数据（后端 note_base.meta_json）
      if (metaJson != null) "metaJson": metaJson,
      if (m['title'] != null) "title": m['title'],

      // "saltB64": ... 如果你客户端没有，就别传，或传空字符串/固定值，取决于你后端约束
      "createdAt": normalizeIso(m['createdAt']),
      "updatedAt": normalizeIso(m['updatedAt']),
      "deleted": isDeleted,
    };

    final result = await Api.apiSaveNote(params); // ✅ 改成新接口名
    final code = int.tryParse(result['code']?.toString() ?? '') ?? -1;
    if (code != 0) return;

    final serverNoteId = result['data']?['noteId'];

    if (isDeleted) {
      // 云端已删除，物理删除本地
      await _notesBox.delete(clientNoteId);
      return;
    }

    // 标记同步成功
    m['isSynced'] = true;
    if (serverNoteId != null) m['serverNoteId'] = serverNoteId;
    // content 仍然不存（加密模式）
    await _notesBox.put(clientNoteId, jsonEncode(m));
  }

  @override
  NoteState build() {
    ref.watch(cryptoProvider);

    ref.onDispose(() {
      _syncTimer?.cancel();
    });

    _syncTimer ??= Timer.periodic(const Duration(seconds: 10), (_) {
      _syncToCloud();
    });

    final key = _masterKey;

    final notes =
        _notesBox.values
            .map((raw) {
              final map = jsonDecode(raw) as Map<String, dynamic>;
              if (map.containsKey('enc')) {
                final enc = map['enc'] as String;
                final noteId = map['id'] as String?;
                String content;
                if (key != null && noteId != null) {
                  try {
                    content = NoteCipher.decryptFromCompactString(
                      masterKey: key,
                      raw: enc,
                      aad: Uint8List.fromList(utf8.encode(noteId)),
                    );
                  } catch (_) {
                    content = '[Decryption failed]';
                  }
                } else {
                  content = '[Encrypted note]';
                }
                map['content'] = content;
              }
              return LocalNote.fromJson(map);
            })
            .where((n) => !n.isDeleted)
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    final prev = stateOrNull;
    LocalNote? nextCurrent;
    final prevId = prev?.currentNote?.id;
    if (prevId != null) {
      for (final n in notes) {
        if (n.id == prevId) {
          nextCurrent = n;
          break;
        }
      }
    }

    nextCurrent ??= (notes.isNotEmpty ? notes.first : null);

    return prev == null
        ? NoteState(notes: notes, currentNote: nextCurrent)
        : prev.copyWith(notes: notes, currentNote: nextCurrent);
  }

  // 内部：按给定文本存一条新笔记到notes_box
  Future<LocalNote> _saveNoteAsNewToHive(
    String text, {
    String type = 'PRIVATE_NOTE',
  }) async {
    final now = DateTime.now();
    final noteId = const Uuid().v4();

    final note = LocalNote(
      id: noteId,
      content: text,
      createdAt: now,
      updatedAt: now,
      serverNoteId: null,
      isSynced: false,
      version: 1,
      type: type,
    );

    final map = note.toJson();
    map['createdAt'] = toIso8601WithOffset(now);
    map['updatedAt'] = toIso8601WithOffset(now);
    final key = _masterKey;
    if (key != null) {
      final enc = NoteCipher.encryptToCompactString(
        masterKey: key,
        plaintext: note.content,
        aad: Uint8List.fromList(utf8.encode(note.id)),
      );
      map['enc'] = enc;
      map.remove('content');
    } else {
      map['content'] = text;
      map.remove('enc');
    }

    await _notesBox.put(noteId, jsonEncode(map));

    final newList = [note, ...state.notes];
    state = state.copyWith(notes: newList, currentNote: note);
    return note;
  }

  // 入口：根据传入文本存一条新笔记
  Future<void> saveCurrentNoteAsNewFromText(
    String text, {
    String type = 'PRIVATE_NOTE',
  }) async {
    await _saveNoteAsNewToHive(text, type: type);
  }

  /// 创建一个全新的空 currentNote（content = ''，version = 1）
  Future<LocalNote> createEmptyCurrentNote({
    String type = 'PRIVATE_NOTE',
  }) async {
    return _saveNoteAsNewToHive('', type: type);
  }

  Future<void> deleteNoteById(String id) async {
    LocalNote? note;
    for (final n in state.notes) {
      if (n.id == id) {
        note = n;
        break;
      }
    }
    if (note == null) return;

    /// delete if never synced
    if (!note.isSynced || note.serverNoteId == null) {
      await _notesBox.delete(id);

      final newList = state.notes.where((n) => n.id != id).toList();
      state = state.copyWith(notes: newList, clearCurrentNote: true);
      return;
    }

    /// if synced, set delete tag, waiting for sync to cloud
    final tombstone = note.copyWith(
      isDeleted: true,
      isSynced: false,
      updatedAt: DateTime.now(),
    );

    // rewrite to hive
    await _notesBox.put(id, jsonEncode(tombstone.toJson()));

    // hide note from UI
    final newList = state.notes.map((n) {
      if (n.id == id) return tombstone;
      return n;
    }).toList();

    state = state.copyWith(notes: newList, clearCurrentNote: true);
  }

  // 更新已有笔记内容
  Future<void> updateNoteById(String id, String newText) async {
    final existing = _findNoteById(id);
    if (existing != null && existing.content == newText) {
      return;
    }
    final raw = _notesBox.get(id);
    final now = DateTime.now();
    final key = _masterKey;

    if (raw == null) {
      // 如果 Hive 里找不到这条，就当作新建一条（可选）
      final note = LocalNote(
        id: id,
        content: newText,
        createdAt: now,
        updatedAt: now,
        serverNoteId: null,
        isSynced: false,
        version: 1,
      );
      final map = note.toJson();
      if (key != null) {
        final enc = NoteCipher.encryptToCompactString(
          masterKey: key,
          plaintext: note.content,
          aad: Uint8List.fromList(utf8.encode(note.id)),
        );
        map['enc'] = enc;
        map.remove('content');
      } else {
        map['content'] = newText;
        map.remove('enc');
      }
      await _notesBox.put(id, jsonEncode(map));
      final newList = [note, ...state.notes];
      state = state.copyWith(notes: newList);
      return;
    }

    // 更新 Hive// ✅ 这里加一条保护：原来是加密的，但现在没 key，就不允许修改
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final bool wasEncrypted = map.containsKey('enc');
    if (wasEncrypted && key == null) {
      // 不改 Hive，不改加密数据，直接返回
      return;
    }
    final int oldVersion = map['version'] as int? ?? 1;
    final int newVersion = oldVersion + 1;
    map['updatedAt'] = toIso8601WithOffset(now);
    map['isSynced'] = false;
    map['version'] = newVersion;
    if (key != null) {
      final enc = NoteCipher.encryptToCompactString(
        masterKey: key,
        plaintext: newText,
        aad: Uint8List.fromList(utf8.encode(id)),
      );
      map['enc'] = enc;
      map.remove('content');
    } else {
      map['content'] = newText;
      map.remove('enc');
    }

    await _notesBox.put(id, jsonEncode(map));

    // 更新 state.notes
    final updatedList = state.notes.map((n) {
      if (n.id == id) {
        return n.copyWith(
          content: newText,
          updatedAt: now,
          isSynced: false,
          version: newVersion,
        );
      }
      return n;
    }).toList();

    state = state.copyWith(
      notes: updatedList,
      currentNote: _findNoteById(id, updatedList),
    );
  }

  /// 退出 / 跳转 / 返回 时调用：
  /// - 如果内容为空 && version == 1 => 删除 hive + state 里的这条 note
  /// - 否则正常 updateNoteById
  Future<void> saveOrDeleteNoteById(String id, String text) async {
    final trimmed = text.trim();

    final raw = _notesBox.get(id);
    if (raw == null) {
      // hive 里没有，直接忽略
      return;
    }

    final map = jsonDecode(raw) as Map<String, dynamic>;
    final int version = map['version'] as int? ?? 1;

    if (trimmed.isEmpty && version == 1) {
      // 新建但没写任何内容的笔记，直接物理删除
      await _notesBox.delete(id);
      final newList = state.notes.where((n) => n.id != id).toList();
      final shouldClearCurrent = state.currentNote?.id == id;
      state = state.copyWith(
        notes: newList,
        clearCurrentNote: shouldClearCurrent,
      );
      return;
    }

    // 有内容 / 或已经 version > 1，就正常保存
    final existing = _findNoteById(id);
    if (existing != null && existing.content == text) {
      return;
    }
    await updateNoteById(id, text);
  }

  Future<void> autoSaveOnBackground(String id, String text) async {
    final trimmed = text.trim();

    final raw = _notesBox.get(id);
    if (raw == null) {
      //hive里没有，直接忽略
      return;
    }

    if (trimmed.isEmpty) {
      //如果内容为空，不保存，也不删除，留给页面逻辑处理
      return;
    }

    final existing = _findNoteById(id);
    if (existing != null && existing.content == text) {
      //内容没变，不用保存
      return;
    }

    ///正常更新内容，更新时间
    await updateNoteById(id, text);
  }

  LocalNote? _findNoteById(String id, [List<LocalNote>? list]) {
    final src = list ?? state.notes;
    for (final n in src) {
      if (n.id == id) return n;
    }
    return null;
  }

  Future<void> removeEmptyNotes() async {
    final masterKey = _masterKey;
    final keysToDelete = <String>[];

    // 1. 找出 Hive 里所有内容空的笔记
    for (final hiveKey in _notesBox.keys) {
      final raw = _notesBox.get(hiveKey);
      if (raw == null) continue;

      final map = jsonDecode(raw) as Map<String, dynamic>;
      final int version = map['version'] as int? ?? 1;

      var content = (map['content'] as String?)?.trim() ?? '';

      // 对加密笔记，能解就用解密后的内容判断是否为空
      if (content.trim().isEmpty && map.containsKey('enc')) {
        final enc = map['enc'] as String;
        final noteId = map['id'] as String?;
        if (masterKey != null && noteId != null) {
          try {
            content = NoteCipher.decryptFromCompactString(
              masterKey: masterKey,
              raw: enc,
              aad: Uint8List.fromList(utf8.encode(noteId)),
            );
          } catch (_) {
            // 解密失败时，不当作空内容删除
          }
        }
      }

      if (content.trim().isEmpty && version == 1) {
        keysToDelete.add(hiveKey as String);
      }
    }

    // 2. 从 Hive 删除这些空记录
    for (final key in keysToDelete) {
      await _notesBox.delete(key);
    }

    // 3. 同步刷新 state.notes（过滤空内容）
    // 重新加载 notes（会自动解密）
    final currentKey = _masterKey;
    final notes =
        _notesBox.values
            .map((raw) {
              final map = jsonDecode(raw) as Map<String, dynamic>;

              if (map.containsKey('enc')) {
                final enc = map['enc'] as String;
                final noteId = map['id'] as String?;
                String content;

                if (currentKey != null && noteId != null) {
                  try {
                    content = NoteCipher.decryptFromCompactString(
                      masterKey: currentKey,
                      raw: enc,
                      aad: Uint8List.fromList(utf8.encode(noteId)),
                    );
                  } catch (_) {
                    content = '[Decryption failed]';
                  }
                } else {
                  content = '[Encrypted note]';
                }

                map['content'] = content;
              }

              return LocalNote.fromJson(map);
            })
            .where((n) => !n.isDeleted)
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    state = state.copyWith(notes: notes);
  }

  bool isNoteEncrypted(String id) {
    final raw = _notesBox.get(id);
    if (raw == null) return false;
    final map = jsonDecode(raw) as Map<String, dynamic>;
    return map.containsKey('enc');
  }

  String? getNoteCiphertext(String id) {
    final raw = _notesBox.get(id);
    if (raw == null) return null;
    final map = jsonDecode(raw) as Map<String, dynamic>;
    return map['enc'] as String?;
  }

  Future<void> uploadNoteById(String clientNoteId) async {
    final raw = _notesBox.get(clientNoteId);
    if (raw == null) return;
    final m = jsonDecode(raw) as Map<String, dynamic>;
    await _uploadRecordToServer(m);
  }

  bool _syncing = false;

  Future<void> _syncToCloud() async {
    if (_syncing) return;
    _syncing = true;

    try {
      if (_masterKey != null) {
        for (final m in _iterPendingRecords()) {
          await _uploadRecordToServer(m);
        }
      }

      await ref.read(sendTaskProvider.notifier).syncToCloud();

      state = build();
    } finally {
      _syncing = false;
    }
  }

  void setCurrentNoteById(String id) {
    LocalNote? note;
    for (final n in state.notes) {
      if (n.id == id) {
        note = n;
        break;
      }
    }
    state = state.copyWith(currentNote: note);
  }

  void clearCurrentNote() {
    state = state.copyWith(clearCurrentNote: true);
  }

  String _decryptEnc({
    required Uint8List masterKey,
    required String noteId,
    required String encRaw,
  }) {
    // 1) JSON format: {"iv":"..","ciphertext":"..","authTag":".."}
    try {
      final o = jsonDecode(encRaw) as Map<String, dynamic>;
      final ivB64 = o['iv'] as String?;
      final ctB64 = o['ciphertext'] as String?;
      final tagB64 = o['authTag'] as String?;
      if (ivB64 != null && ctB64 != null && tagB64 != null) {
        return NoteCipher.decryptFromParts(
          masterKey: masterKey,
          ivB64: ivB64,
          cipherTextB64: ctB64,
          tagB64: tagB64,
          aad: Uint8List.fromList(utf8.encode(noteId)),
        );
      }
    } catch (_) {
      // not json, fallback
    }

    // 2) compact format fallback
    return NoteCipher.decryptFromCompactString(
      masterKey: masterKey,
      raw: encRaw,
      aad: Uint8List.fromList(utf8.encode(noteId)),
    );
  }

  Future<void> upsertBusinessNote({
    required String noteId,
    required String noteType, // e.g. 'LAST_WISHES'
    required String title,
    required String plainText,
    required Map<String, dynamic> meta,
  }) async {
    final now = DateTime.now();
    final key = _masterKey;

    final raw = _notesBox.get(noteId);

    // 如果原来是加密记录，但现在没有 key，不允许改（保持你现有策略）
    if (raw != null) {
      final existingMap = jsonDecode(raw) as Map<String, dynamic>;
      final bool wasEncrypted = existingMap.containsKey('enc');
      if (wasEncrypted && key == null) return;
    }

    Map<String, dynamic> map;
    int newVersion;

    if (raw == null) {
      // 新建固定 noteId 的记录
      map = <String, dynamic>{
        'id': noteId,
        'serverNoteId': null,
        'isSynced': false,
        'isDeleted': false,
        'version': 1,
        'type': noteType,
        'title': title,
        'meta': meta,
        'createdAt': toIso8601WithOffset(now),
        'updatedAt': toIso8601WithOffset(now),
      };
      newVersion = 1;
    } else {
      map = jsonDecode(raw) as Map<String, dynamic>;
      final int oldVersion = map['version'] as int? ?? 1;
      newVersion = oldVersion + 1;

      map['updatedAt'] = toIso8601WithOffset(now);
      map['isSynced'] = false;
      map['version'] = newVersion;

      // 覆盖/写入业务字段（不影响 serverNoteId 等）
      map['type'] = noteType;
      map['title'] = title;
      map['meta'] = meta;
    }

    // content -> enc/content
    if (key != null) {
      final enc = NoteCipher.encryptToCompactString(
        masterKey: key,
        plaintext: plainText,
        aad: Uint8List.fromList(utf8.encode(noteId)),
      );
      map['enc'] = enc;
      map.remove('content');
    } else {
      map['content'] = plainText;
      map.remove('enc');
    }

    await _notesBox.put(noteId, jsonEncode(map));

    // 刷新 state（给 UI 立即可见）
    final exists = _findNoteById(noteId);
    final local = LocalNote.fromJson({
      ...map,
      // LocalNote 里如果需要 content 字段，这里给解密后的内容
      'content': plainText,
    });

    if (exists == null) {
      state = state.copyWith(
        notes: [local, ...state.notes],
        currentNote: local,
      );
    } else {
      final updated = state.notes.map((n) {
        if (n.id == noteId) {
          return n.copyWith(
            content: plainText,
            updatedAt: now,
            isSynced: false,
            version: newVersion,
            type: noteType,
          );
        }
        return n;
      }).toList();

      state = state.copyWith(
        notes: updated,
        currentNote: state.currentNote?.id == noteId
            ? _findNoteById(noteId, updated)
            : state.currentNote,
      );
    }
  }
}
