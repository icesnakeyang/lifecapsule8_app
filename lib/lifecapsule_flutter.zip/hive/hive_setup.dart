import 'package:hive_flutter/hive_flutter.dart';
import 'package:lifecapsule8_app/hive/hive_boxes.dart';

class HiveSetup {
  static Future<void> init() async {
    await Hive.initFlutter();
    await Hive.openBox<String>(HiveBoxes.notes);
    await Hive.openBox(HiveBoxes.crypto);
    await Hive.openBox(HiveBoxes.loveLetterDrafts);
    await Hive.openBox<String>(HiveBoxes.sendTasks);
    await Hive.openBox<String>(HiveBoxes.lastWishes);
    await Hive.openBox<String>(HiveBoxes.inspirationBox);
    await Hive.openBox<String>(HiveBoxes.futureBox);
  }

  // 建议使用 deleteBoxFromDisk 防止旧文件残留
  static Future<void> clearHive() async {
    await Hive.deleteBoxFromDisk(HiveBoxes.notes);
    await Hive.deleteBoxFromDisk(HiveBoxes.crypto);
    await Hive.deleteBoxFromDisk(HiveBoxes.loveLetterDrafts);
    await Hive.deleteBoxFromDisk(HiveBoxes.sendTasks);
    await Hive.deleteBoxFromDisk(HiveBoxes.lastWishes);
    await Hive.deleteBoxFromDisk(HiveBoxes.inspirationBox);
    await Hive.deleteBoxFromDisk(HiveBoxes.futureBox);
  }
}
